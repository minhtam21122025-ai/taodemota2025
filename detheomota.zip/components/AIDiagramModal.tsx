import React, { useState } from 'react';
import { generateDiagramFromText } from '../services/geminiService';

interface AIDiagramModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (svgCode: string) => void;
}

const AIDiagramModal: React.FC<AIDiagramModalProps> = ({ isOpen, onClose, onSave }) => {
  const [description, setDescription] = useState('');
  const [svgOutput, setSvgOutput] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
      if (!description.trim()) return;
      setIsLoading(true);
      setError(null);
      setSvgOutput(null);
      try {
          const svg = await generateDiagramFromText(description);
          setSvgOutput(svg);
      } catch (err) {
          setError("Không thể tạo hình. Vui lòng thử lại với mô tả khác.");
      } finally {
          setIsLoading(false);
      }
  };

  const handleInsert = () => {
      if (svgOutput) {
          onSave(svgOutput);
          onClose();
          setDescription('');
          setSvgOutput(null);
      }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-fade-in">
      <div className="bg-white rounded-3xl w-full max-w-4xl flex flex-col shadow-2xl overflow-hidden max-h-[90vh]">
        <div className="flex justify-between items-center p-5 border-b border-slate-100 bg-gradient-to-r from-emerald-50 to-blue-50">
            <h3 className="text-xl font-bold text-slate-800 flex items-center">
                <span className="bg-emerald-100 text-emerald-600 p-2 rounded-lg mr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09z" />
                  </svg>
                </span>
                AI Tạo Hình Minh Họa
            </h3>
            <button onClick={onClose} className="text-slate-400 hover:text-red-500 transition-colors p-2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 flex flex-col md:flex-row gap-6">
            <div className="flex-1 space-y-4">
                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">Mô tả hình vẽ:</label>
                    <textarea
                        className="w-full rounded-2xl border-slate-200 border bg-slate-50 p-4 text-sm focus:bg-white focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all h-40 resize-none font-medium text-slate-700"
                        placeholder="Ví dụ: Vẽ đồ thị hàm số y = x^2, trục Ox Oy có mũi tên, có đánh dấu đỉnh O(0,0)..."
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        disabled={isLoading}
                    />
                </div>
                <button 
                    onClick={handleGenerate}
                    disabled={isLoading || !description.trim()}
                    className={`w-full py-4 rounded-2xl font-bold text-sm flex items-center justify-center transition-all ${
                        isLoading || !description.trim() 
                        ? 'bg-slate-100 text-slate-400 cursor-not-allowed' 
                        : 'bg-slate-900 text-white hover:bg-black shadow-xl'
                    }`}
                >
                    {isLoading ? "Đang xử lý..." : "Bắt đầu vẽ hình"}
                </button>
                {error && <p className="text-xs text-red-500 bg-red-50 p-3 rounded-lg border border-red-100">{error}</p>}
            </div>

            <div className="flex-1 flex flex-col border border-slate-200 rounded-3xl overflow-hidden bg-slate-50">
                <div className="bg-white/50 px-4 py-3 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase flex justify-between items-center">
                    <span>Xem trước kết quả</span>
                    {svgOutput && <span className="text-[10px] bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">SVG Sẵn sàng</span>}
                </div>
                <div className="flex-1 flex items-center justify-center bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] p-8 min-h-[300px]">
                    {svgOutput ? (
                        <div dangerouslySetInnerHTML={{ __html: svgOutput }} className="w-full h-full flex items-center justify-center max-w-md bg-white p-4 rounded-xl shadow-sm border border-slate-100" />
                    ) : (
                        <div className="text-center">
                            <div className="bg-slate-200/50 p-4 rounded-full mb-3 inline-block">
                              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-12 h-12 text-slate-400">
                                  <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
                              </svg>
                            </div>
                            <p className="text-sm text-slate-400 font-medium">Hình vẽ sẽ hiển thị tại đây</p>
                        </div>
                    )}
                </div>
            </div>
        </div>

        <div className="p-5 border-t border-slate-100 bg-white flex justify-end space-x-3">
             <button onClick={onClose} className="px-6 py-3 rounded-2xl border border-slate-200 text-slate-600 font-bold hover:bg-slate-50">Hủy</button>
             <button
                onClick={handleInsert}
                disabled={!svgOutput}
                className={`px-8 py-3 rounded-2xl font-bold flex items-center shadow-lg transition-all ${
                    !svgOutput ? 'bg-slate-200 text-slate-400 cursor-not-allowed' : 'bg-emerald-600 text-white hover:bg-emerald-700'
                }`}
            >
                Chèn vào đề thi
            </button>
        </div>
      </div>
    </div>
  );
};

export default AIDiagramModal;