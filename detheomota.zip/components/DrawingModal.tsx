import React, { useRef, useState, useEffect } from 'react';

interface DrawingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (dataUrl: string) => void;
}

type Tool = 'pen' | 'line' | 'rect' | 'circle' | 'eraser';

const DrawingModal: React.FC<DrawingModalProps> = ({ isOpen, onClose, onSave }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [context, setContext] = useState<CanvasRenderingContext2D | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [tool, setTool] = useState<Tool>('pen');
  const [lineWidth, setLineWidth] = useState<number>(2);
  const [startPos, setStartPos] = useState<{ x: number; y: number } | null>(null);
  const [snapshot, setSnapshot] = useState<ImageData | null>(null);
  
  // History for Undo
  const [history, setHistory] = useState<ImageData[]>([]);

  useEffect(() => {
    if (isOpen && canvasRef.current) {
      const canvas = canvasRef.current;
      
      // Set canvas size to match container (minus padding/toolbar)
      const parent = canvas.parentElement;
      if (parent) {
          canvas.width = parent.clientWidth;
          canvas.height = parent.clientHeight;
      }

      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.strokeStyle = '#000000';
        // Fill white background initially to ensure it's not transparent when saving jpg/png
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        setContext(ctx);
        saveToHistory(ctx, canvas);
      }
    }
  }, [isOpen]);

  const saveToHistory = (ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement) => {
      const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
      setHistory(prev => [...prev.slice(-10), data]); // Keep last 10 steps
  };

  const handleUndo = () => {
      if (!context || !canvasRef.current || history.length <= 1) return;
      
      const newHistory = [...history];
      newHistory.pop(); // Remove current state
      const previousState = newHistory[newHistory.length - 1];
      
      if (previousState) {
          context.putImageData(previousState, 0, 0);
          setHistory(newHistory);
      }
  };

  const getPos = (e: React.MouseEvent | React.TouchEvent) => {
      if (!canvasRef.current) return { x: 0, y: 0 };
      const rect = canvasRef.current.getBoundingClientRect();
      let clientX, clientY;

      if ('touches' in e) {
          clientX = e.touches[0].clientX;
          clientY = e.touches[0].clientY;
      } else {
          clientX = (e as React.MouseEvent).clientX;
          clientY = (e as React.MouseEvent).clientY;
      }

      return {
          x: clientX - rect.left,
          y: clientY - rect.top
      };
  };

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    if (!context || !canvasRef.current) return;
    
    // Prevent scrolling when touching canvas
    // e.preventDefault(); 

    setIsDrawing(true);
    const { x, y } = getPos(e);
    setStartPos({ x, y });
    setSnapshot(context.getImageData(0, 0, canvasRef.current.width, canvasRef.current.height));

    context.beginPath();
    context.moveTo(x, y);
    context.lineWidth = lineWidth;
    context.strokeStyle = tool === 'eraser' ? '#ffffff' : '#000000';
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || !context || !canvasRef.current || !startPos) return;
    // e.preventDefault();

    const { x, y } = getPos(e);

    if (tool === 'pen' || tool === 'eraser') {
        context.lineTo(x, y);
        context.stroke();
    } else if (snapshot) {
        // Restore snapshot to avoid trails for shapes
        context.putImageData(snapshot, 0, 0);
        context.beginPath();

        if (tool === 'line') {
            context.moveTo(startPos.x, startPos.y);
            context.lineTo(x, y);
        } else if (tool === 'rect') {
            context.strokeRect(startPos.x, startPos.y, x - startPos.x, y - startPos.y);
        } else if (tool === 'circle') {
            const radius = Math.sqrt(Math.pow(x - startPos.x, 2) + Math.pow(y - startPos.y, 2));
            context.arc(startPos.x, startPos.y, radius, 0, 2 * Math.PI);
        }
        context.stroke();
    }
  };

  const stopDrawing = () => {
    if (isDrawing && context && canvasRef.current) {
        context.closePath();
        setIsDrawing(false);
        saveToHistory(context, canvasRef.current);
    }
  };

  const handleClear = () => {
      if (!context || !canvasRef.current) return;
      context.fillStyle = '#ffffff';
      context.fillRect(0, 0, canvasRef.current.width, canvasRef.current.height);
      saveToHistory(context, canvasRef.current);
  };

  const handleSave = () => {
      if (canvasRef.current) {
          const dataUrl = canvasRef.current.toDataURL('image/png');
          onSave(dataUrl);
          onClose();
      }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl w-full max-w-5xl h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b border-slate-200 bg-slate-50">
            <h3 className="text-lg font-bold text-slate-800 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 mr-2 text-indigo-600">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9.53 16.122a3 3 0 00-5.78 1.128 2.25 2.25 0 01-2.4 2.245 4.5 4.5 0 008.4-2.245c0-.399-.078-.78-.22-1.128zm0 0a15.998 15.998 0 003.388-1.62m-5.043-.025a15.994 15.994 0 011.622-3.395m3.42 3.42a15.995 15.995 0 004.764-4.648l3.876-5.814a1.151 1.151 0 00-1.597-1.597L14.146 6.32a16.001 16.001 0 00-4.649 4.763m3.42 3.42a6.776 6.776 0 00-3.42-3.42" />
                </svg>
                Bảng vẽ hình
            </h3>
            <button onClick={onClose} className="text-slate-400 hover:text-red-500 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>

        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-2 p-3 bg-white border-b border-slate-200">
            <div className="flex bg-slate-100 p-1 rounded-lg">
                {[
                    { id: 'pen', icon: <path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" />, label: 'Bút' },
                    { id: 'line', icon: <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 4.5l-15 15" />, label: 'Đường thẳng' },
                    { id: 'rect', icon: <rect x="3" y="3" width="18" height="18" rx="2" strokeWidth="2" fill="none" />, label: 'HCN' },
                    { id: 'circle', icon: <circle cx="12" cy="12" r="9" strokeWidth="2" fill="none" />, label: 'Tròn' },
                    { id: 'eraser', icon: <path strokeLinecap="round" strokeLinejoin="round" d="M12 9.75L14.25 12m0 0l2.25 2.25M14.25 12l2.25-2.25M14.25 12L12 14.25m-2.58 4.92l-6.375-6.375a1.125 1.125 0 010-1.59L9.42 4.83c.211-.211.498-.33.796-.33H19.5a2.25 2.25 0 012.25 2.25v10.5a2.25 2.25 0 01-2.25 2.25h-9.284c-.298 0-.585-.119-.796-.33z" />, label: 'Tẩy' }
                ].map((item) => (
                    <button
                        key={item.id}
                        onClick={() => setTool(item.id as Tool)}
                        className={`p-2 rounded-md transition-all ${tool === item.id ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                        title={item.label}
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                            {item.icon}
                        </svg>
                    </button>
                ))}
            </div>

            <div className="h-6 w-px bg-slate-300 mx-2"></div>

            <div className="flex items-center space-x-2">
                <span className="text-xs font-bold text-slate-500 uppercase">Nét:</span>
                <input 
                    type="range" 
                    min="1" 
                    max="10" 
                    value={lineWidth} 
                    onChange={(e) => setLineWidth(parseInt(e.target.value))}
                    className="w-24 h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-slate-600"
                />
                <span className="text-xs font-mono w-4">{lineWidth}</span>
            </div>

            <div className="flex-1"></div>

             <div className="flex bg-slate-100 p-1 rounded-lg">
                <button
                    onClick={handleUndo}
                    className="p-2 rounded-md text-slate-500 hover:text-slate-800 hover:bg-white transition-all"
                    title="Hoàn tác"
                >
                     <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M9 15L3 9m0 0l6-6M3 9h12a6 6 0 010 12h-3" />
                    </svg>
                </button>
                <button
                    onClick={handleClear}
                    className="p-2 rounded-md text-red-500 hover:text-red-700 hover:bg-white transition-all"
                    title="Xóa tất cả"
                >
                     <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
                    </svg>
                </button>
            </div>
        </div>

        {/* Canvas Area */}
        <div className="flex-1 bg-slate-100 relative cursor-crosshair touch-none overflow-hidden">
            <canvas
                ref={canvasRef}
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
                onTouchStart={startDrawing}
                onTouchMove={draw}
                onTouchEnd={stopDrawing}
                className="absolute inset-0 block w-full h-full bg-white shadow-inner"
            />
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-white flex justify-end space-x-3">
             <button
                onClick={onClose}
                className="px-5 py-2.5 rounded-xl border border-slate-200 text-slate-600 font-bold hover:bg-slate-50"
            >
                Hủy
            </button>
            <button
                onClick={handleSave}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 text-white font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-500/30 flex items-center"
            >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5 mr-2">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                </svg>
                Chèn vào đề
            </button>
        </div>
      </div>
    </div>
  );
};

export default DrawingModal;