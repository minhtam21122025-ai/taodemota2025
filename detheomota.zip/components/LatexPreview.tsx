import React, { useState, useEffect, useRef } from "react";
import { ExamVariant } from "../types";
import DrawingModal from "./DrawingModal";
import AIDiagramModal from "./AIDiagramModal";
import { convertLatexToHtml } from "../services/geminiService";

interface LatexPreviewProps {
  latexCode: string;
  htmlContent: string;
  variants?: ExamVariant[];
  isEditable?: boolean;
}

const LatexPreview: React.FC<LatexPreviewProps> = ({ latexCode: initialLatex, htmlContent: initialHtml, variants = [], isEditable = false }) => {
  const [activeTab, setActiveTab] = useState<'preview' | 'latex'>('preview');
  const [currentVariantIndex, setCurrentVariantIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const [isDrawingOpen, setIsDrawingOpen] = useState(false);
  const [isAIDiagramOpen, setIsAIDiagramOpen] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  
  const [displayedHtml, setDisplayedHtml] = useState<string>("");
  const [localLatexCode, setLocalLatexCode] = useState<string>("");
  
  const previewRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const preRef = useRef<HTMLPreElement>(null);

  const currentVariant = variants.length > 0 ? variants[currentVariantIndex] : { latexCode: initialLatex, htmlContent: initialHtml };

  useEffect(() => {
    setDisplayedHtml(currentVariant.htmlContent);
    setLocalLatexCode(currentVariant.latexCode);
  }, [currentVariant.htmlContent, currentVariant.latexCode, currentVariantIndex]);

  useEffect(() => {
    if (activeTab === 'preview' && previewRef.current && (window as any).renderMathInElement) {
      setTimeout(() => {
        (window as any).renderMathInElement(previewRef.current, {
          delimiters: [
            { left: "$$", right: "$$", display: true },
            { left: "$", right: "$", display: false }
          ],
          throwOnError: false
        });
      }, 100);
    }
  }, [displayedHtml, activeTab, currentVariantIndex]);

  const handleShuffle = () => {
    if (!displayedHtml) return;
    const parser = new DOMParser();
    const doc = parser.parseFromString(displayedHtml, 'text/html');
    const optionGrids = doc.querySelectorAll('.options-grid');
    optionGrids.forEach(grid => {
        const options = Array.from(grid.children);
        for (let i = options.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            grid.appendChild(options[j]); 
        }
    });
    setDisplayedHtml(doc.body.innerHTML);
  };

  const handleInsertDrawing = (dataUrl: string) => {
      const imgHtml = `
        <div class="diagram-container">
            <img src="${dataUrl}" class="hand-drawn-image" alt="Hình vẽ tay" />
            <div class="diagram-caption">Hình vẽ bổ sung</div>
        </div>
      `;
      setDisplayedHtml(prev => prev + imgHtml);
  };

  const handleInsertAIDiagram = (svgCode: string) => {
      const svgHtml = `
        <div class="diagram-container">
            ${svgCode}
            <div class="diagram-caption">Hình minh họa (AI)</div>
        </div>
      `;
      setDisplayedHtml(prev => prev + svgHtml);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(localLatexCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleUpdatePreview = async () => {
      setIsUpdating(true);
      try {
          const newHtml = await convertLatexToHtml(localLatexCode);
          setDisplayedHtml(newHtml);
          setActiveTab('preview');
      } catch (error) {
          alert("Lỗi khi cập nhật xem trước.");
      } finally {
          setIsUpdating(false);
      }
  };

  const handlePrintPDF = () => {
    setActiveTab('preview');
    setTimeout(() => window.print(), 300);
  };

  const handleDownloadWord = () => {
    const header = "<html><head><meta charset='utf-8'></head><body><div class='paper-sheet'>";
    const footer = "</div></body></html>";
    const blob = new Blob(['\ufeff', header + displayedHtml + footer], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const element = document.createElement("a");
    element.href = url;
    element.download = `Exam_Paper_${currentVariantIndex + 1}.doc`;
    element.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex flex-col border-b border-white/50 bg-white/60 backdrop-blur-md shadow-sm z-10">
          {variants.length > 1 && (
            <div className="flex px-4 pt-4 space-x-2 overflow-x-auto custom-scrollbar">
                {variants.map((_, idx) => (
                    <button key={idx} onClick={() => setCurrentVariantIndex(idx)} className={`px-4 py-2 text-sm font-bold border-b-2 transition-all ${currentVariantIndex === idx ? 'border-blue-600 text-blue-700 bg-blue-50/80' : 'border-transparent text-slate-500'}`}>{`Mã đề ${idx + 1}`}</button>
                ))}
            </div>
          )}
          <div className="flex items-center justify-between p-3 px-4">
            <div className="flex p-1 bg-slate-200/50 rounded-lg">
              <button onClick={() => setActiveTab('preview')} className={`px-4 py-1.5 text-xs font-bold uppercase rounded-md transition-all ${activeTab === 'preview' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500'}`}>Xem trước</button>
              {isEditable && <button onClick={() => setActiveTab('latex')} className={`px-4 py-1.5 text-xs font-bold uppercase rounded-md transition-all ${activeTab === 'latex' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500'}`}>LaTeX Code</button>}
            </div>

            <div className="flex space-x-2">
               {activeTab === 'latex' && isEditable && (
                   <button onClick={handleUpdatePreview} disabled={isUpdating} className="flex items-center px-3 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm">
                       {isUpdating ? "..." : "Cập nhật"}
                   </button>
               )}
               {activeTab === 'preview' && (
               <>
                <button
                    onClick={() => setIsAIDiagramOpen(true)}
                    className="flex items-center px-3 py-1.5 text-xs font-bold text-white bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 rounded-lg shadow-md transition-all group"
                    title="Vẽ hình bằng AI"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4 mr-1.5 group-hover:animate-pulse">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09z" />
                    </svg>
                    AI Vẽ
                </button>
                <button onClick={() => setIsDrawingOpen(true)} className="flex items-center px-3 py-1.5 text-xs font-bold text-purple-700 bg-white border border-slate-200 hover:bg-purple-50 rounded-lg shadow-sm">Vẽ</button>
                <button onClick={handleShuffle} className="flex items-center px-3 py-1.5 text-xs font-bold text-amber-700 bg-white border border-slate-200 hover:bg-amber-50 rounded-lg shadow-sm">Đảo đề</button>
               </>
              )}
              <button onClick={handleDownloadWord} className="flex items-center px-3 py-1.5 text-xs font-bold text-slate-700 bg-white border border-slate-200 hover:bg-blue-50 rounded-lg shadow-sm">Word</button>
              <button onClick={handlePrintPDF} className="flex items-center px-3 py-1.5 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-lg">PDF</button>
            </div>
          </div>
      </div>

      <div className="flex-1 overflow-hidden relative bg-slate-100/50 p-4 md:p-8">
        {activeTab === 'preview' ? (
          <div className="h-full overflow-y-auto custom-scrollbar flex justify-center">
            <div ref={previewRef} className="paper-sheet w-full max-w-[210mm] min-h-full bg-white text-slate-900 shadow-2xl p-[20mm] md:p-[25mm] rounded-2xl" dangerouslySetInnerHTML={{ __html: displayedHtml }} />
          </div>
        ) : (
          <div className="h-full rounded-xl overflow-hidden shadow-inner border border-slate-300 relative bg-[#2d2d2d]">
             <textarea readOnly={!isEditable} value={localLatexCode} onChange={(e) => setLocalLatexCode(e.target.value)} className="absolute inset-0 w-full h-full p-6 bg-transparent text-white caret-white outline-none resize-none custom-scrollbar font-mono text-sm" />
          </div>
        )}
      </div>
      <DrawingModal isOpen={isDrawingOpen} onClose={() => setIsDrawingOpen(false)} onSave={handleInsertDrawing} />
      <AIDiagramModal isOpen={isAIDiagramOpen} onClose={() => setIsAIDiagramOpen(false)} onSave={handleInsertAIDiagram} />
    </div>
  );
};

export default LatexPreview;