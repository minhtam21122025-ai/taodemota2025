import React, { useState, useRef, useEffect } from "react";
import mammoth from "mammoth";
import {
  ExamConfig,
  Subject,
  Grade,
  ExamType,
  GenerationMode,
  DifficultyStructure,
  DifficultyLevel,
  UploadedFile,
  Structure7991
} from "../types";
import {
  SUBJECT_OPTIONS,
  GRADE_OPTIONS,
  EXAM_TYPE_OPTIONS,
  DIFFICULTY_OPTIONS,
  CURRICULUM_TOPICS,
  GENERIC_TOPICS
} from "../constants";

interface ExamFormProps {
  config: ExamConfig;
  setConfig: (config: ExamConfig) => void;
  isLoading: boolean;
  progress?: { current: number; total: number } | null;
  hasResults?: boolean;
  onSubmit: () => void;
  onCancel: () => void;
  onClear?: () => void;
}

const ExamForm: React.FC<ExamFormProps> = ({
  config,
  setConfig,
  isLoading,
  progress,
  hasResults,
  onSubmit,
  onCancel,
  onClear,
}) => {
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const matrixInputRef = useRef<HTMLInputElement>(null);
  const referenceInputRef = useRef<HTMLInputElement>(null);

  // Load available topics based on subject and grade
  const [availableTopics, setAvailableTopics] = useState<string[]>([]);

  useEffect(() => {
    // Reset selected topics when subject or grade changes to avoid inconsistent state
    const subjectData = CURRICULUM_TOPICS[config.subject];
    let newTopics = GENERIC_TOPICS;
    
    if (subjectData && subjectData[config.grade]) {
        newTopics = subjectData[config.grade];
    }
    
    setAvailableTopics(newTopics);

    // Filter out topics that are no longer valid for the new subject/grade
    const validTopics = (config.selectedTopics || []).filter(t => newTopics.includes(t));
    if (validTopics.length !== (config.selectedTopics || []).length) {
         handleChange("selectedTopics", validTopics);
    }
  }, [config.subject, config.grade]);

  const handleChange = <K extends keyof ExamConfig>(
    key: K,
    value: ExamConfig[K]
  ) => {
    setConfig({ ...config, [key]: value });
  };

  const handleTopicToggle = (topic: string) => {
      const currentTopics = config.selectedTopics || [];
      if (currentTopics.includes(topic)) {
          handleChange("selectedTopics", currentTopics.filter(t => t !== topic));
      } else {
          handleChange("selectedTopics", [...currentTopics, topic]);
      }
  };

  const handleSelectAllTopics = () => {
      handleChange("selectedTopics", [...availableTopics]);
  };

  const handleDeselectAllTopics = () => {
      handleChange("selectedTopics", []);
  };

  const handleStructureChange = (
    key: keyof DifficultyStructure,
    value: string
  ) => {
    const numValue = parseInt(value, 10) || 0;
    setConfig({
      ...config,
      structure: { ...config.structure, [key]: numValue },
    });
  };

  const handleStructure7991Change = (
    key: keyof Structure7991,
    value: string
  ) => {
    const numValue = parseInt(value, 10) || 0;
    setConfig({
        ...config,
        structure7991: { ...config.structure7991, [key]: numValue }
    });
  };

  // Helper to get suggestions based on subject
  const getSubjectSuggestions = (subject: Subject): string[] => {
    switch (subject) {
      case Subject.MATH:
        return [
          "Tập trung vào tính đơn điệu và cực trị, có bài toán thực tế.",
          "Bài toán lãi suất ngân hàng và tối ưu hóa.",
          "Hình học: Tính khoảng cách và góc trong không gian."
        ];
      case Subject.LITERATURE:
        return [
          "Phân tích giá trị nhân đạo.",
          "Nghị luận về trách nhiệm của tuổi trẻ.",
        ];
      case Subject.ENGLISH:
        return [
          "Chủ đề: Daily Life.",
          "Câu điều kiện loại 1, 2 và câu bị động.",
          "Reading passage về chủ đề Environment."
        ];
      case Subject.PHYSICS:
        return [
          "Con lắc lò xo và bài toán năng lượng.",
          "Mạch RLC nối tiếp và công suất tiêu thụ."
        ];
      case Subject.CHEMISTRY:
        return [
          "Bài tập đốt cháy Este.",
          "Nhận biết các chất vô cơ."
        ];
      default:
        return [
          "Đề thi bám sát cấu trúc đề minh họa.",
          "Tập trung vào các câu hỏi vận dụng thực tiễn."
        ];
    }
  };

  const suggestions = getSubjectSuggestions(config.subject);

  // Generic file processor
  const processFileGeneric = async (file: File, targetField: 'uploadedFile' | 'matrixFile' | 'referenceFile') => {
    const validTypes = [
        'application/pdf', 
        'image/png', 'image/jpeg', 'image/webp', 
        'text/plain', 'text/markdown',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // docx
        'application/msword' // doc
    ];
    const validExts = ['.tex', '.txt', '.md', '.docx', '.doc'];
    
    const isNameValid = validExts.some(ext => file.name.toLowerCase().endsWith(ext));
    const isTypeValid = validTypes.includes(file.type);

    if (!isTypeValid && !isNameValid) {
        alert("Chỉ hỗ trợ file PDF, Word (.docx), Ảnh (PNG, JPG), hoặc văn bản (TXT, TEX, MD)");
        return;
    }

    // Handle Word (.docx) Extraction
    if (file.name.toLowerCase().endsWith('.docx') || file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
        const reader = new FileReader();
        reader.onload = async (e) => {
            const arrayBuffer = e.target?.result as ArrayBuffer;
            if (arrayBuffer) {
                try {
                    const result = await mammoth.extractRawText({ arrayBuffer });
                    
                    // If target is sampleContent (uploadedFile), fill the text area for better context
                    if (targetField === 'uploadedFile') {
                        // Append to existing sample content or replace
                        const newContent = config.sampleContent ? config.sampleContent + "\n\n" + result.value : result.value;
                        handleChange("sampleContent", newContent);
                    } else {
                        // For matrix/reference, we treat it as a text file upload
                         const base64Text = btoa(unescape(encodeURIComponent(result.value)));
                         const uploadObj: UploadedFile = {
                             data: base64Text,
                             mimeType: 'text/plain',
                             fileName: file.name.replace('.docx', '.txt')
                         };
                         handleChange(targetField, uploadObj);
                    }
                } catch (err) {
                    console.error("Mammoth error:", err);
                    alert("Không thể đọc nội dung file Word (.docx). Vui lòng đảm bảo file không bị lỗi.");
                }
            }
        };
        reader.readAsArrayBuffer(file);
        return;
    }

    // Handle old Word (.doc) - Warn user
    if (file.name.toLowerCase().endsWith('.doc') || file.type === 'application/msword') {
        alert("Lưu ý: File .doc (Word 97-2003) không được hỗ trợ trích xuất văn bản trực tiếp. Vui lòng chuyển sang định dạng .docx hoặc PDF để có kết quả tốt nhất.");
        return;
    }

    // Handle Text Files
    if (file.type.startsWith('text/') || file.name.endsWith('.tex') || file.name.endsWith('.md') || file.name.endsWith('.txt')) {
         const reader = new FileReader();
         reader.onload = (e) => {
             const text = e.target?.result as string;
             if (targetField === 'uploadedFile') {
                 handleChange("sampleContent", text);
             } else {
                 // For reference/matrix, keep as file but mime text/plain
                 const base64Text = btoa(unescape(encodeURIComponent(text)));
                 const uploadObj: UploadedFile = {
                     data: base64Text,
                     mimeType: 'text/plain',
                     fileName: file.name
                 };
                 handleChange(targetField, uploadObj);
             }
         };
         reader.readAsText(file);
         return;
    }

    // Handle Binary Files (PDF, Images) - Default for Vision API
    const reader = new FileReader();
    reader.onload = (e) => {
        const base64String = e.target?.result as string;
        // Remove data URL prefix (e.g., "data:image/png;base64,")
        const base64Data = base64String.split(',')[1];
        
        const uploadObj: UploadedFile = {
            data: base64Data,
            mimeType: file.type,
            fileName: file.name
        };
        handleChange(targetField, uploadObj);
    };
    reader.readAsDataURL(file);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent, target: 'uploadedFile' | 'matrixFile' | 'referenceFile') => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFileGeneric(e.dataTransfer.files[0], target);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, target: 'uploadedFile' | 'matrixFile' | 'referenceFile') => {
    if (e.target.files && e.target.files[0]) {
      processFileGeneric(e.target.files[0], target);
    }
  };

  return (
    <div className="h-full flex flex-col p-4 md:p-6 overflow-y-auto custom-scrollbar">
      {/* 1. Header Area */}
      <div className="mb-6">
        <h2 className="text-xl font-bold text-slate-800 flex items-center">
            <span className="bg-blue-100 text-blue-600 w-8 h-8 rounded-lg flex items-center justify-center mr-2 text-sm" aria-hidden="true">1</span>
            Cấu hình đề thi
        </h2>
        <p className="text-xs text-slate-500 ml-10">Điền thông tin để AI tạo đề chính xác</p>
      </div>

      <div className="space-y-5 flex-1">
        {/* Grid Selectors */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <label htmlFor="subject-select" className="text-xs font-bold text-slate-600 uppercase">Môn học</label>
            <div className="relative">
                <select
                id="subject-select"
                className="w-full p-2.5 bg-white border border-slate-200 rounded-lg text-sm font-medium focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none appearance-none"
                value={config.subject}
                onChange={(e) => handleChange("subject", e.target.value as Subject)}
                disabled={isLoading}
                >
                {SUBJECT_OPTIONS.map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                ))}
                </select>
                <div className="absolute right-3 top-3 pointer-events-none text-slate-400">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4">
                        <path fillRule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clipRule="evenodd" />
                    </svg>
                </div>
            </div>
          </div>
          <div className="space-y-1">
            <label htmlFor="grade-select" className="text-xs font-bold text-slate-600 uppercase">Khối lớp</label>
             <div className="relative">
                <select
                id="grade-select"
                className="w-full p-2.5 bg-white border border-slate-200 rounded-lg text-sm font-medium focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none appearance-none"
                value={config.grade}
                onChange={(e) => handleChange("grade", e.target.value as Grade)}
                disabled={isLoading}
                >
                {GRADE_OPTIONS.map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                ))}
                </select>
                <div className="absolute right-3 top-3 pointer-events-none text-slate-400">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4">
                        <path fillRule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clipRule="evenodd" />
                    </svg>
                </div>
            </div>
          </div>
          <div className="space-y-1">
            <label htmlFor="difficulty-select" className="text-xs font-bold text-slate-600 uppercase">Độ khó</label>
            <div className="relative">
                <select
                id="difficulty-select"
                className="w-full p-2.5 bg-white border border-slate-200 rounded-lg text-sm font-medium focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none appearance-none"
                value={config.difficultyLevel}
                onChange={(e) => handleChange("difficultyLevel", e.target.value as DifficultyLevel)}
                disabled={isLoading}
                >
                {DIFFICULTY_OPTIONS.map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                ))}
                </select>
                 <div className="absolute right-3 top-3 pointer-events-none text-slate-400">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4">
                        <path fillRule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clipRule="evenodd" />
                    </svg>
                </div>
            </div>
          </div>
          <div className="space-y-1">
            <label htmlFor="exam-type-select" className="text-xs font-bold text-slate-600 uppercase">Loại bài</label>
            <div className="relative">
                <select
                id="exam-type-select"
                className="w-full p-2.5 bg-white border border-slate-200 rounded-lg text-sm font-medium focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none appearance-none"
                value={config.examType}
                onChange={(e) => handleChange("examType", e.target.value as ExamType)}
                disabled={isLoading}
                >
                {EXAM_TYPE_OPTIONS.map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                ))}
                </select>
                <div className="absolute right-3 top-3 pointer-events-none text-slate-400">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4">
                        <path fillRule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clipRule="evenodd" />
                    </svg>
                </div>
            </div>
          </div>
        </div>

        {/* Topics Selection */}
        <div className="space-y-2">
             <div className="flex justify-between items-end">
                <label className="text-xs font-bold text-slate-600 uppercase">Chủ đề / Bài học (Tùy chọn)</label>
                <div className="space-x-2">
                    <button type="button" onClick={handleSelectAllTopics} className="text-[10px] text-blue-600 hover:underline">Chọn tất cả</button>
                    <span className="text-slate-300" aria-hidden="true">|</span>
                    <button type="button" onClick={handleDeselectAllTopics} className="text-[10px] text-red-500 hover:underline">Bỏ chọn</button>
                </div>
             </div>
             <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto custom-scrollbar p-2 bg-slate-50 rounded-lg border border-slate-200" role="group" aria-label="Danh sách chủ đề">
                {availableTopics.map(topic => {
                    const isSelected = config.selectedTopics?.includes(topic);
                    return (
                        <button
                            key={topic}
                            type="button"
                            onClick={() => handleTopicToggle(topic)}
                            aria-pressed={isSelected}
                            className={`px-3 py-1 rounded-full text-xs transition-all border ${
                                isSelected
                                ? 'bg-blue-100 text-blue-700 border-blue-200 font-bold'
                                : 'bg-white text-slate-600 border-slate-200 hover:border-blue-300'
                            }`}
                        >
                            {topic}
                        </button>
                    );
                })}
             </div>
        </div>

        {/* Mode Selector */}
        <div className="bg-slate-100 p-1 rounded-xl flex" role="tablist" aria-label="Chế độ tạo đề">
            {[GenerationMode.DESCRIPTION, GenerationMode.STRUCTURE, GenerationMode.SAMPLE, GenerationMode.OFFICIAL_7991].map(mode => (
                <button
                    key={mode}
                    type="button"
                    role="tab"
                    aria-selected={config.mode === mode}
                    onClick={() => handleChange("mode", mode)}
                    className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                        config.mode === mode
                        ? 'bg-white text-blue-700 shadow-sm'
                        : 'text-slate-500 hover:text-slate-700'
                    }`}
                >
                   {mode === GenerationMode.OFFICIAL_7991 ? 'CV 7991' : mode}
                </button>
            ))}
        </div>

        {/* Mode Content */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
            {config.mode === GenerationMode.DESCRIPTION && (
                <div className="space-y-2 animate-fade-in" role="tabpanel">
                    <label htmlFor="description-input" className="text-xs font-bold text-slate-600 uppercase">Mô tả yêu cầu chi tiết</label>
                    <textarea
                        id="description-input"
                        className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none h-32 resize-none"
                        placeholder="Ví dụ: Tạo đề thi tập trung vào phần Hàm số mũ, có 3 câu vận dụng cao về bài toán lãi suất..."
                        value={config.description}
                        onChange={(e) => handleChange("description", e.target.value)}
                    />
                    <div className="flex flex-wrap gap-2 mt-2">
                        {suggestions.map((s, i) => (
                            <button key={i} type="button" onClick={() => handleChange("description", s)} className="text-[10px] bg-blue-50 text-blue-600 px-2 py-1 rounded-md hover:bg-blue-100 transition-colors text-left truncate max-w-full">
                                + {s}
                            </button>
                        ))}
                    </div>
                </div>
            )}

            {config.mode === GenerationMode.STRUCTURE && (
                <div className="animate-fade-in" role="tabpanel">
                    <label className="text-xs font-bold text-slate-600 uppercase mb-3 block">Phân bổ số lượng câu hỏi</label>
                    <div className="grid grid-cols-2 gap-3">
                         {[
                             { id: 'easy', label: 'Nhận biết', color: 'bg-green-50 text-green-700' },
                             { id: 'medium', label: 'Thông hiểu', color: 'bg-blue-50 text-blue-700' },
                             { id: 'hard', label: 'Vận dụng', color: 'bg-orange-50 text-orange-700' },
                             { id: 'veryHard', label: 'Vận dụng cao', color: 'bg-red-50 text-red-700' }
                         ].map(level => (
                             <div key={level.id} className={`${level.color} p-3 rounded-lg border border-transparent hover:border-current transition-all`}>
                                 <label htmlFor={`struct-${level.id}`} className="block text-xs font-bold mb-1">{level.label}</label>
                                 <input
                                    id={`struct-${level.id}`}
                                    type="number"
                                    min="0"
                                    className="w-full bg-white/50 border border-black/10 rounded px-2 py-1 text-sm font-bold text-center outline-none focus:bg-white"
                                    value={config.structure[level.id as keyof DifficultyStructure]}
                                    onChange={(e) => handleStructureChange(level.id as keyof DifficultyStructure, e.target.value)}
                                 />
                             </div>
                         ))}
                    </div>
                </div>
            )}
            
            {config.mode === GenerationMode.OFFICIAL_7991 && (
                 <div className="animate-fade-in" role="tabpanel">
                    <label className="text-xs font-bold text-slate-600 uppercase mb-3 block">Cấu trúc Công văn 7991</label>
                    <div className="space-y-3">
                         <div className="p-3 bg-indigo-50 rounded-lg border border-indigo-100 flex items-center justify-between">
                             <div className="flex-1">
                                 <label htmlFor="cv-part1" className="text-xs font-bold text-indigo-800 cursor-pointer">PHẦN I: Trắc nghiệm nhiều lựa chọn</label>
                                 <p className="text-[10px] text-indigo-600">Chọn 1 đáp án đúng A, B, C, D</p>
                             </div>
                             <input
                                id="cv-part1"
                                type="number" min="0" className="w-16 ml-3 p-1.5 rounded border border-indigo-200 text-center font-bold text-sm"
                                value={config.structure7991.part1} onChange={(e) => handleStructure7991Change('part1', e.target.value)}
                             />
                         </div>
                         <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-100 flex items-center justify-between">
                             <div className="flex-1">
                                 <label htmlFor="cv-part2" className="text-xs font-bold text-emerald-800 cursor-pointer">PHẦN II: Trắc nghiệm Đúng/Sai</label>
                                 <p className="text-[10px] text-emerald-600">Mỗi câu có 4 ý a), b), c), d)</p>
                             </div>
                             <input
                                id="cv-part2"
                                type="number" min="0" className="w-16 ml-3 p-1.5 rounded border border-emerald-200 text-center font-bold text-sm"
                                value={config.structure7991.part2} onChange={(e) => handleStructure7991Change('part2', e.target.value)}
                             />
                         </div>
                         <div className="p-3 bg-amber-50 rounded-lg border border-amber-100 flex items-center justify-between">
                             <div className="flex-1">
                                 <label htmlFor="cv-part3" className="text-xs font-bold text-amber-800 cursor-pointer">PHẦN III: Trắc nghiệm trả lời ngắn</label>
                                 <p className="text-[10px] text-amber-600">Điền số hoặc đáp án ngắn</p>
                             </div>
                             <input
                                id="cv-part3"
                                type="number" min="0" className="w-16 ml-3 p-1.5 rounded border border-amber-200 text-center font-bold text-sm"
                                value={config.structure7991.part3} onChange={(e) => handleStructure7991Change('part3', e.target.value)}
                             />
                         </div>
                         <div className="p-3 bg-rose-50 rounded-lg border border-rose-100 flex items-center justify-between">
                             <div className="flex-1">
                                 <label htmlFor="cv-part4" className="text-xs font-bold text-rose-800 cursor-pointer">PHẦN IV: Tự luận</label>
                                 <p className="text-[10px] text-rose-600">Trình bày lời giải chi tiết (nếu có)</p>
                             </div>
                             <input
                                id="cv-part4"
                                type="number" min="0" className="w-16 ml-3 p-1.5 rounded border border-rose-200 text-center font-bold text-sm"
                                value={config.structure7991.part4} onChange={(e) => handleStructure7991Change('part4', e.target.value)}
                             />
                         </div>
                    </div>
                </div>
            )}

            {config.mode === GenerationMode.SAMPLE && (
                 <div className="space-y-3 animate-fade-in" role="tabpanel">
                    <div 
                        role="button"
                        aria-label="Tải lên file mẫu"
                        className={`border-2 border-dashed rounded-xl p-6 text-center transition-all ${
                            dragActive ? "border-blue-500 bg-blue-50" : "border-slate-300 bg-slate-50 hover:bg-slate-100"
                        }`}
                        onDragEnter={handleDrag}
                        onDragLeave={handleDrag}
                        onDragOver={handleDrag}
                        onDrop={(e) => handleDrop(e, 'uploadedFile')}
                        onClick={() => fileInputRef.current?.click()}
                    >
                        <input 
                            ref={fileInputRef} 
                            type="file" 
                            className="hidden" 
                            accept=".pdf,image/*,.txt,.md,.tex,.doc,.docx"
                            onChange={(e) => handleFileChange(e, 'uploadedFile')} 
                        />
                        {config.uploadedFile ? (
                            <div className="flex items-center justify-center text-emerald-600">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6 mr-2" aria-hidden="true">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                <span className="text-sm font-bold truncate max-w-[150px]">{config.uploadedFile.fileName}</span>
                            </div>
                        ) : (
                            <div className="flex flex-col items-center text-slate-400">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 mb-2" aria-hidden="true">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" />
                                </svg>
                                <p className="text-xs font-bold">Tải lên file mẫu</p>
                                <p className="text-[10px]">Word (.docx), PDF, Ảnh, Text</p>
                            </div>
                        )}
                    </div>
                    
                    <div>
                         <label htmlFor="sample-text-input" className="text-xs font-bold text-slate-600 uppercase">Nội dung văn bản (Trích xuất hoặc nhập tay)</label>
                         <textarea
                            id="sample-text-input"
                            className="w-full p-3 mt-1 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none h-24 resize-none"
                            placeholder="Nội dung đề thi mẫu sẽ hiện ở đây sau khi tải file, hoặc bạn có thể copy-paste vào..."
                            value={config.sampleContent}
                            onChange={(e) => handleChange("sampleContent", e.target.value)}
                        />
                    </div>
                </div>
            )}
        </div>
        
        {/* Additional Files (Matrix & Reference) */}
        <div className="space-y-3">
             <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-600 uppercase flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-1" aria-hidden="true">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                    </svg>
                    File Ma trận / Đặc tả (Nếu có)
                </label>
                {config.matrixFile && (
                    <button type="button" onClick={() => handleChange('matrixFile', null)} className="text-[10px] text-red-500 hover:underline">Xóa</button>
                )}
             </div>
             <div 
                 role="button"
                 aria-label="Tải lên Ma trận"
                 onClick={() => matrixInputRef.current?.click()}
                 className={`border border-dashed rounded-lg p-3 flex items-center justify-center cursor-pointer transition-colors ${config.matrixFile ? 'bg-emerald-50 border-emerald-300' : 'bg-white border-slate-300 hover:bg-slate-50'}`}
             >
                 <input ref={matrixInputRef} type="file" className="hidden" accept=".pdf,.docx,.txt" onChange={(e) => handleFileChange(e, 'matrixFile')} />
                 {config.matrixFile ? (
                     <span className="text-xs font-bold text-emerald-700 truncate">{config.matrixFile.fileName}</span>
                 ) : (
                     <span className="text-xs text-slate-400">+ Tải lên Ma trận (PDF/Word/Text)</span>
                 )}
             </div>

             <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-600 uppercase flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-1" aria-hidden="true">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
                    </svg>
                    Tài liệu tham khảo / SGK (Nếu có)
                </label>
                {config.referenceFile && (
                    <button type="button" onClick={() => handleChange('referenceFile', null)} className="text-[10px] text-red-500 hover:underline">Xóa</button>
                )}
             </div>
             <div 
                 role="button"
                 aria-label="Tải lên Tài liệu tham khảo"
                 onClick={() => referenceInputRef.current?.click()}
                 className={`border border-dashed rounded-lg p-3 flex items-center justify-center cursor-pointer transition-colors ${config.referenceFile ? 'bg-indigo-50 border-indigo-300' : 'bg-white border-slate-300 hover:bg-slate-50'}`}
             >
                 <input ref={referenceInputRef} type="file" className="hidden" accept=".pdf,.docx,.txt" onChange={(e) => handleFileChange(e, 'referenceFile')} />
                 {config.referenceFile ? (
                     <span className="text-xs font-bold text-indigo-700 truncate">{config.referenceFile.fileName}</span>
                 ) : (
                     <span className="text-xs text-slate-400">+ Tải lên Tài liệu (PDF/Word/Text)</span>
                 )}
             </div>
        </div>

        {/* Variants Count */}
        <div className="flex items-center justify-between p-3 bg-slate-100 rounded-lg">
            <label className="text-xs font-bold text-slate-600 uppercase">Số lượng đề cần tạo</label>
            <div className="flex items-center space-x-2">
                <button 
                    type="button"
                    aria-label="Giảm số lượng đề"
                    onClick={() => handleChange("numberOfVariants", Math.max(1, config.numberOfVariants - 1))}
                    className="w-8 h-8 rounded-full bg-white text-slate-600 shadow-sm font-bold hover:bg-slate-50"
                >
                    -
                </button>
                <span className="w-8 text-center font-bold text-lg" aria-live="polite">{config.numberOfVariants}</span>
                <button 
                    type="button"
                    aria-label="Tăng số lượng đề"
                    onClick={() => handleChange("numberOfVariants", Math.min(5, config.numberOfVariants + 1))}
                    className="w-8 h-8 rounded-full bg-white text-slate-600 shadow-sm font-bold hover:bg-slate-50"
                >
                    +
                </button>
            </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-8 pt-4 border-t border-slate-200">
        {isLoading ? (
            <div className="space-y-3">
                 <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden" role="progressbar" aria-valuenow={progress ? (progress.current / progress.total) * 100 : 0} aria-valuemin={0} aria-valuemax={100}>
                    <div 
                        className="bg-blue-600 h-2.5 rounded-full transition-all duration-500" 
                        style={{ width: progress ? `${(progress.current / progress.total) * 100}%` : '0%' }}
                    ></div>
                 </div>
                 <p className="text-xs text-center text-slate-500 font-medium">
                     Đang khởi tạo đề {progress ? `${progress.current + 1}/${progress.total}` : '...'}. Vui lòng đợi...
                 </p>
                 <button
                    type="button"
                    onClick={onCancel}
                    className="w-full py-3 rounded-xl border border-red-200 text-red-600 font-bold hover:bg-red-50 transition-colors"
                 >
                    Hủy bỏ
                 </button>
            </div>
        ) : (
            <div className="flex gap-3">
                {hasResults && onClear && (
                     <button
                        type="button"
                        onClick={onClear}
                        className="flex-1 py-3 rounded-xl border border-slate-200 text-slate-600 font-bold hover:bg-slate-50 transition-colors"
                    >
                        Xóa kết quả
                    </button>
                )}
                <button
                    type="button"
                    onClick={onSubmit}
                    className="flex-[2] py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold rounded-xl shadow-lg shadow-blue-500/30 hover:shadow-blue-500/50 hover:scale-[1.02] active:scale-95 transition-all flex justify-center items-center"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5 mr-2" aria-hidden="true">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.894 20.567L16.5 21.75l-.394-1.183a2.25 2.25 0 00-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 001.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 001.423 1.423l1.183.394-1.183.394a2.25 2.25 0 00-1.423 1.423z" />
                    </svg>
                    Tạo đề ngay
                </button>
            </div>
        )}
      </div>
    </div>
  );
};

export default ExamForm;