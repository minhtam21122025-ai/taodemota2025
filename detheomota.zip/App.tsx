import React, { useState, useRef, useEffect } from "react";
import ExamForm from "./components/ExamForm";
import LatexPreview from "./components/LatexPreview";
import HistoryModal from "./components/HistoryModal";
import LoginScreen from "./components/LoginScreen"; // Import lại LoginScreen
import { DEFAULT_CONFIG } from "./constants";
import { generateSingleVariant } from "./services/geminiService";
import { ExamConfig, GenerateResponse, HistoryItem, ExamVariant } from "./types";

// Link nhạc Lo-fi nhẹ nhàng (Copyright Free)
const BG_MUSIC_URL = "https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=lofi-study-112191.mp3";

// User Interface
interface User {
  name: string;
  email: string;
}

function App() {
  // Authentication State
  const [user, setUser] = useState<User | null>(null);

  const [config, setConfig] = useState<ExamConfig>(DEFAULT_CONFIG);
  const [result, setResult] = useState<GenerateResponse>({ variants: [] });
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [progress, setProgress] = useState<{ current: number; total: number } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  
  // Mobile Tab State: 'config' or 'preview'
  const [activeMobileTab, setActiveMobileTab] = useState<'config' | 'preview'>('config');
  
  // Track active request to handle cancellations
  const abortControllerRef = useRef<boolean>(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Initialize Audio
  useEffect(() => {
    audioRef.current = new Audio(BG_MUSIC_URL);
    audioRef.current.loop = true;
    audioRef.current.volume = 0.4; // Âm lượng vừa phải
    return () => {
        if (audioRef.current) {
            audioRef.current.pause();
            audioRef.current = null;
        }
    };
  }, []);

  // Control Audio based on loading state
  useEffect(() => {
    if (!audioRef.current) return;

    if (isLoading && !isMuted) {
        audioRef.current.play().catch(e => console.log("Audio autoplay blocked:", e));
    } else {
        audioRef.current.pause();
        if (!isLoading) {
            audioRef.current.currentTime = 0; // Reset nhạc khi xong
        }
    }
  }, [isLoading, isMuted]);

  const addToHistory = (config: ExamConfig, variants: ExamVariant[]) => {
    if (variants.length === 0) return;
    const newItem: HistoryItem = {
      id: Date.now().toString(),
      timestamp: Date.now(),
      configSummary: `${config.subject} - ${config.grade} - ${config.examType} (${variants.length} đề)`,
      variants: variants
    };
    setHistory(prev => [newItem, ...prev]);
  };

  const handleSelectHistory = (item: HistoryItem) => {
      setResult({ variants: item.variants });
      setActiveMobileTab('preview'); // Switch to preview on mobile when history selected
  };

  const handleDeleteHistory = (id: string) => {
      setHistory(prev => prev.filter(item => item.id !== id));
  };

  const handleClearResults = () => {
      setResult({ variants: [] });
      setError(null);
      setProgress(null);
      setActiveMobileTab('config'); // Switch back to config on clear
  };

  const handleLogin = (userData: User) => {
    setUser(userData);
  };

  const handleLogout = () => {
    setUser(null);
    setResult({ variants: [] });
    setActiveMobileTab('config');
  };

  const handleSubmit = async () => {
    // Reset flags
    abortControllerRef.current = false;

    setIsLoading(true);
    setError(null);
    setResult({ variants: [] }); // Clear previous results
    
    // Switch to preview tab on mobile to show loading state
    setActiveMobileTab('preview');

    const totalVariants = config.numberOfVariants;
    setProgress({ current: 0, total: totalVariants });

    const newVariants: ExamVariant[] = [];
    
    // Create an array of promises for parallel execution
    const promises = Array.from({ length: totalVariants }).map(async (_, index) => {
        if (abortControllerRef.current) return null;

        try {
            // Pass index + 1 as variant number (1-based)
            const variant = await generateSingleVariant(config, index + 1);
            
            if (abortControllerRef.current) return null;

            // Update state incrementally as each request finishes
            setResult(prev => ({
                variants: [...prev.variants, variant]
            }));
            
            newVariants.push(variant);
            
            setProgress(prev => prev ? { ...prev, current: prev.current + 1 } : null);
            
            return variant;
        } catch (err: any) {
            console.error(err);
            // Optionally handle individual failures here without stopping the whole batch
            // For now, we just don't add it to the list
            return null;
        }
    });

    try {
        await Promise.all(promises);
        
        // After all finished, save to history if we have results and wasn't aborted
        if (!abortControllerRef.current && newVariants.length > 0) {
            addToHistory(config, newVariants);
        } else if (newVariants.length === 0 && !abortControllerRef.current) {
            setError("Không thể tạo đề nào. Vui lòng thử lại.");
            setActiveMobileTab('config'); // Go back to config if failed
        }

    } catch (err: any) {
         setError(err.message || "Đã xảy ra lỗi không mong muốn");
         setActiveMobileTab('config');
    } finally {
        setIsLoading(false);
        setProgress(null);
        abortControllerRef.current = false;
    }
  };

  const handleCancel = () => {
    abortControllerRef.current = true;
    setIsLoading(false);
    setProgress(null);
    setActiveMobileTab('config');
  };

  // Condition to render Login Screen
  if (!user) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 font-sans text-slate-800">
      {/* Header with Glassmorphism */}
      <header className="sticky top-0 z-20 flex items-center justify-between px-4 md:px-6 h-16 bg-white/70 backdrop-blur-md border-b border-white/40 shadow-sm">
        <div className="flex items-center space-x-2 md:space-x-3">
          <div className="bg-gradient-to-tr from-blue-600 to-indigo-600 p-1.5 md:p-2 rounded-xl shadow-lg shadow-blue-500/30">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className="w-5 h-5 md:w-6 md:h-6 text-white"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M4.26 10.147a60.436 60.436 0 00-.491 6.347A48.627 48.627 0 0112 20.904a48.627 48.627 0 018.232-4.41 60.46 60.46 0 00-.491-6.347m-15.482 0a50.57 50.57 0 00-2.658-.8138.833 0 01-2.434 4.153h2.247l.869.2195a1 1 0 00.999-1.508l-1.678-4.412z"
              />
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M12 3a6 6 0 100 12 6 6 0 000-12z"
              />
            </svg>
          </div>
          <h1 className="text-xl md:text-2xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-blue-700 to-purple-600 truncate">
            ExamGen <span className="font-light text-slate-500">Pro</span>
          </h1>
        </div>
        
        <div className="flex items-center space-x-2 md:space-x-3">
            {/* Music Toggle */}
            <button
                onClick={() => setIsMuted(!isMuted)}
                className={`p-2 rounded-full transition-all duration-300 ${isMuted ? 'bg-slate-200 text-slate-500' : 'bg-indigo-100 text-indigo-600 hover:bg-indigo-200'}`}
                title={isMuted ? "Bật nhạc nền" : "Tắt nhạc nền"}
            >
                {isMuted ? (
                     <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 9.75L19.5 12m0 0l2.25 2.25M19.5 12l2.25-2.25M19.5 12l-2.25 2.25m-10.5-6l4.72-4.72a.75.75 0 011.28.53v15.88a.75.75 0 01-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.01 9.01 0 012.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75z" />
                     </svg>
                ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M19.114 5.636a9 9 0 010 12.728M16.463 8.288a5.25 5.25 0 010 7.424M6.75 8.25l4.72-4.72a.75.75 0 011.28.53v15.88a.75.75 0 01-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.01 9.01 0 012.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75z" />
                    </svg>
                )}
            </button>

            <button 
                onClick={() => setIsHistoryOpen(true)}
                className="flex items-center px-3 py-2 md:px-4 text-sm font-semibold text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 hover:text-blue-600 hover:border-blue-200 rounded-full transition-all shadow-sm active:scale-95"
            >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 md:mr-2">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span className="hidden md:inline">Lịch sử</span>
                {history.length > 0 && (
                    <span className="bg-blue-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full ml-1 md:ml-2 shadow-sm">
                        {history.length}
                    </span>
                )}
            </button>

            {/* Profile / Logout Button */}
            <div className="relative group">
                <button className="flex items-center space-x-2 pl-3 border-l border-slate-300 ml-1">
                    <div className="w-9 h-9 rounded-full bg-gradient-to-r from-teal-400 to-emerald-500 text-white flex items-center justify-center font-bold text-sm shadow-md">
                        {user.name.charAt(0).toUpperCase()}
                    </div>
                </button>
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-slate-100 overflow-hidden transform opacity-0 scale-95 group-hover:opacity-100 group-hover:scale-100 transition-all duration-200 origin-top-right">
                    <div className="px-4 py-3 border-b border-slate-100">
                        <p className="text-sm font-bold text-slate-800 truncate">{user.name}</p>
                        <p className="text-xs text-slate-500 truncate">{user.email}</p>
                    </div>
                    <button 
                        onClick={handleLogout}
                        className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors flex items-center"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-2">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75" />
                        </svg>
                        Đăng xuất
                    </button>
                </div>
            </div>
        </div>
      </header>

      {/* Mobile Tabs Navigation */}
      <div className="md:hidden flex border-b border-slate-200 bg-white z-10">
          <button 
            onClick={() => setActiveMobileTab('config')}
            className={`flex-1 py-3 text-sm font-bold border-b-2 transition-colors ${
                activeMobileTab === 'config' 
                ? 'border-blue-600 text-blue-700 bg-blue-50/50' 
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            1. Cấu hình
          </button>
          <button 
            onClick={() => setActiveMobileTab('preview')}
            className={`flex-1 py-3 text-sm font-bold border-b-2 transition-colors ${
                activeMobileTab === 'preview' 
                ? 'border-blue-600 text-blue-700 bg-blue-50/50' 
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            2. Xem đề {result.variants.length > 0 && `(${result.variants.length})`}
          </button>
      </div>

      {/* Main Content */}
      <main className="flex-1 flex overflow-hidden relative">
        {/* Left Panel: Configuration */}
        <div 
            className={`
                w-full md:w-1/3 lg:w-1/4 bg-white/60 backdrop-blur-xl border-r border-white/50 shadow-[4px_0_24px_-4px_rgba(0,0,0,0.05)] z-10 overflow-hidden
                ${activeMobileTab === 'config' ? 'block absolute inset-0 md:static' : 'hidden md:block'}
            `}
        >
          <ExamForm
            config={config}
            setConfig={setConfig}
            isLoading={isLoading}
            progress={progress}
            hasResults={result.variants.length > 0}
            onSubmit={handleSubmit}
            onCancel={handleCancel}
            onClear={handleClearResults}
          />
        </div>

        {/* Right Panel: Preview */}
        <div 
            className={`
                flex-1 flex flex-col min-w-0 relative
                ${activeMobileTab === 'preview' ? 'block absolute inset-0 md:static' : 'hidden md:block'}
            `}
        >
            {error && (
                <div className="absolute top-6 left-6 right-6 bg-red-50/90 backdrop-blur-sm border border-red-200 text-red-700 px-4 py-3 rounded-xl relative z-50 shadow-lg animate-fade-in" role="alert">
                    <div className="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6 mr-2 text-red-500">
                          <path fillRule="evenodd" d="M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.4 3.003zM12 8.25a.75.75 0 01.75.75v3.75a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zm0 8.25a.75.75 0 100-1.5.75.75 0 000 1.5z" clipRule="evenodd" />
                        </svg>
                        <strong className="font-bold">Lỗi! </strong>
                        <span className="block sm:inline ml-1">{error}</span>
                    </div>
                    <span className="absolute top-0 bottom-0 right-0 px-4 py-3 cursor-pointer" onClick={() => setError(null)}>
                        <svg className="fill-current h-6 w-6 text-red-400 hover:text-red-600" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
                    </span>
                </div>
            )}
            <LatexPreview 
              latexCode={result.variants[0]?.latexCode || ""} 
              htmlContent={result.variants[0]?.htmlContent || ""}
              variants={result.variants}
              isEditable={user?.email === 'daotam28@gmail.com'}
            />
        </div>
      </main>

      <HistoryModal 
        isOpen={isHistoryOpen} 
        onClose={() => setIsHistoryOpen(false)}
        history={history}
        onSelect={handleSelectHistory}
        onDelete={handleDeleteHistory}
      />
    </div>
  );
}

export default App;