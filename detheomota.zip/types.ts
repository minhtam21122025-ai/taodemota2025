export enum Subject {
  MATH = 'Toán học',
  LITERATURE = 'Ngữ văn',
  ENGLISH = 'Tiếng Anh',
  PHYSICS = 'Vật lí',
  CHEMISTRY = 'Hóa học',
  BIOLOGY = 'Sinh học',
  HISTORY = 'Lịch sử',
  GEOGRAPHY = 'Địa lí',
  NATURAL_SCI = 'Khoa học tự nhiên', // THCS
  HISTORY_GEOGRAPHY = 'Lịch sử và Địa lí', // THCS
  GDKT_PL = 'Giáo dục Kinh tế và Pháp luật', // THPT
  CIVIC_EDU = 'Giáo dục công dân', // THCS
  INFORMATICS = 'Tin học',
  TECHNOLOGY = 'Công nghệ',
  DEFENSE_EDU = 'Giáo dục Quốc phòng và An ninh'
}

export enum Grade {
  GRADE_6 = 'Lớp 6',
  GRADE_7 = 'Lớp 7',
  GRADE_8 = 'Lớp 8',
  GRADE_9 = 'Lớp 9',
  GRADE_10 = 'Lớp 10',
  GRADE_11 = 'Lớp 11',
  GRADE_12 = 'Lớp 12',
  UNIVERSITY = 'Đại học'
}

export enum ExamType {
  FIFTEEN_MIN_HK1_1 = '15 phút - Bài số 1 (HK I)',
  FIFTEEN_MIN_HK1_2 = '15 phút - Bài số 2 (HK I)',
  MID_TERM_HK1 = 'Kiểm tra giữa kì I',
  FINAL_TERM_HK1 = 'Kiểm tra cuối kì I',
  
  FIFTEEN_MIN_HK2_1 = '15 phút - Bài số 1 (HK II)',
  FIFTEEN_MIN_HK2_2 = '15 phút - Bài số 2 (HK II)',
  MID_TERM_HK2 = 'Kiểm tra giữa kì II',
  FINAL_TERM_HK2 = 'Kiểm tra cuối kì II',

  MOCK_TEST = 'Thi thử THPT QG',
  ENTRANCE_10 = 'Thi vào lớp 10'
}

export enum GenerationMode {
  DESCRIPTION = 'Theo mô tả',
  STRUCTURE = 'Theo cấu trúc',
  SAMPLE = 'Theo đề mẫu',
  OFFICIAL_7991 = 'Theo CV 7991'
}

export enum DifficultyLevel {
  BASIC = 'Cơ bản',
  MEDIUM = 'Trung bình',
  ADVANCED = 'Nâng cao'
}

export interface DifficultyStructure {
  easy: number;
  medium: number;
  hard: number;
  veryHard: number;
}

// Cấu trúc cho CV 7991
export interface Structure7991 {
  part1: number; // Trắc nghiệm nhiều lựa chọn
  part2: number; // Trắc nghiệm đúng sai
  part3: number; // Trắc nghiệm trả lời ngắn
  part4: number; // Tự luận (nếu có)
}

export interface UploadedFile {
  data: string; // Base64 string without prefix
  mimeType: string;
  fileName: string;
}

export interface ExamConfig {
  subject: Subject;
  grade: Grade;
  examType: ExamType;
  difficultyLevel: DifficultyLevel;
  mode: GenerationMode;
  description: string;
  structure: DifficultyStructure;
  structure7991: Structure7991; // New field for 7991 mode
  sampleContent: string;
  uploadedFile: UploadedFile | null; // Used for "Theo đề mẫu"
  matrixFile: UploadedFile | null;   // New: Ma trận đề thi
  referenceFile: UploadedFile | null;// New: Tài liệu tham khảo
  numberOfVariants: number;
  selectedTopics: string[]; // New: Danh sách chủ đề kiến thức được chọn
}

export interface ExamVariant {
  latexCode: string;
  htmlContent: string;
}

export interface GenerateResponse {
  variants: ExamVariant[];
}

export interface HistoryItem {
  id: string;
  timestamp: number;
  configSummary: string;
  variants: ExamVariant[];
}