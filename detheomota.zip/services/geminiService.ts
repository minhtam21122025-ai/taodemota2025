import { GoogleGenAI, Type } from "@google/genai";
import { ExamConfig, GenerationMode, ExamVariant } from "../types";

export const generateSingleVariant = async (config: ExamConfig, variantIndex: number): Promise<ExamVariant> => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("API Key chưa được cấu hình.");
  }

  const ai = new GoogleGenAI({ apiKey });

  let promptDetail = "";
  let parts: any[] = [];

  // Base prompt focused on a SINGLE variant
  let basePrompt = `Hãy tạo ĐỀ THI SỐ ${variantIndex} (trong bộ ${config.numberOfVariants} đề).
  - Môn học: ${config.subject}
  - Trình độ: ${config.grade}
  - Loại bài kiểm tra: ${config.examType}
  - Mức độ khó chung: ${config.difficultyLevel}`;

  // Add selected topics if available
  if (config.selectedTopics && config.selectedTopics.length > 0) {
      basePrompt += `\n- NỘI DUNG TRỌNG TÂM CẦN KIỂM TRA: ${config.selectedTopics.join(", ")}. Hãy tập trung phần lớn câu hỏi vào các chủ đề này.`;
  }
  
  basePrompt += `\n\nQUAN TRỌNG: Đây là đề thứ ${variantIndex}. Hãy thay đổi số liệu, nội dung câu hỏi hoặc ngữ cảnh để đảm bảo nó KHÁC BIỆT so với các đề khác, nhưng vẫn giữ nguyên cấu trúc và độ khó.`;

  if (config.mode === GenerationMode.DESCRIPTION) {
    promptDetail = `Yêu cầu chi tiết bổ sung: "${config.description}"`;
    parts.push({ text: `${basePrompt}\n${promptDetail}` });
  } else if (config.mode === GenerationMode.STRUCTURE) {
    promptDetail = `Cấu trúc đề thi (số lượng câu hỏi):
    - Nhận biết (Dễ): ${config.structure.easy} câu
    - Thông hiểu (TB): ${config.structure.medium} câu
    - Vận dụng (Khó): ${config.structure.hard} câu
    - Vận dụng cao (Rất khó): ${config.structure.veryHard} câu
    
    Lưu ý: Tuân thủ mức độ khó chung là "${config.difficultyLevel}" khi biên soạn nội dung từng câu hỏi.`;
    parts.push({ text: `${basePrompt}\n${promptDetail}` });
  } else if (config.mode === GenerationMode.OFFICIAL_7991) {
    const s7991 = config.structure7991;
    
    promptDetail = `TUÂN THỦ CẤU TRÚC CÔNG VĂN 7991 (4 Phần):
    1. PHẦN I: Trắc nghiệm nhiều lựa chọn (${s7991.part1} Câu).
    2. PHẦN II: Trắc nghiệm Đúng/Sai (${s7991.part2} Câu).
    3. PHẦN III: Trắc nghiệm trả lời ngắn (${s7991.part3} Câu).
    4. PHẦN IV: Tự luận (${s7991.part4} Câu).`;
    parts.push({ text: `${basePrompt}\n${promptDetail}` });

  } else if (config.mode === GenerationMode.SAMPLE) {
    promptDetail = `Dựa vào tài liệu mẫu, hãy tạo ra đề thi mới tương tự (thay đổi số liệu/câu hỏi).`;
    let fullTextPrompt = `${basePrompt}\n${promptDetail}`;
    if (config.sampleContent) fullTextPrompt += `\n--- NỘI DUNG VĂN BẢN ĐÍNH KÈM ---\n${config.sampleContent}`;
    parts.push({ text: fullTextPrompt });
    if (config.uploadedFile) {
        parts.push({ inlineData: { data: config.uploadedFile.data, mimeType: config.uploadedFile.mimeType } });
    }
  }

  if (config.matrixFile) {
      parts.push({ text: "\n\n--- MA TRẬN / ĐẶC TẢ ĐỀ THI ---" });
      parts.push({ inlineData: { data: config.matrixFile.data, mimeType: config.matrixFile.mimeType } });
  }
  if (config.referenceFile) {
      parts.push({ text: "\n\n--- TÀI LIỆU THAM KHẢO ---" });
      parts.push({ inlineData: { data: config.referenceFile.data, mimeType: config.referenceFile.mimeType } });
  }

  const systemInstruction = `Bạn là chuyên gia soạn đề thi giáo dục. Nhiệm vụ: Tạo 01 đề thi hoàn chỉnh, BẢNG ĐÁP ÁN (concise) VÀ HƯỚNG DẪN GIẢI CHI TIẾT.

  YÊU CẦU:
  1. LaTeX Code: \\documentclass[14pt]{extarticle}.
  2. HTML Structure: Wrap questions in <div class="question-box">, Answer Key in <div class="answer-key-section">, Solutions in <div class="solution-section">.
  3. SVG for Diagrams: Create responsive SVGs in <div class="diagram-container"> if needed.

  Return JSON: { "latexCode": "...", "htmlContent": "..." }`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{ role: "user", parts: parts }],
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7, 
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            latexCode: { type: Type.STRING },
            htmlContent: { type: Type.STRING },
          },
          required: ["latexCode", "htmlContent"],
        },
      },
    });

    const result = JSON.parse(response.text || "{}");
    let latex = result.latexCode || "";
    if (latex.startsWith("```latex")) latex = latex.replace(/^```latex/, "").replace(/```$/, "");
    return { latexCode: latex.trim(), htmlContent: (result.htmlContent || "").trim() };
  } catch (error) {
    console.error(`Gemini Error:`, error);
    throw new Error(`Lỗi khi tạo đề số ${variantIndex}.`);
  }
};

export const convertLatexToHtml = async (latexCode: string): Promise<string> => {
    const apiKey = process.env.API_KEY;
    if (!apiKey) throw new Error("API Key missing");
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Convert this LaTeX to HTML body content. Use <div class="question-box"> for questions and <div class="solution-section"> for solutions. LATEX: ${latexCode}`,
        config: { temperature: 0.1, responseMimeType: "text/plain" }
    });
    let html = response.text || "";
    return html.replace(/```html|```/g, "").trim();
};

export const generateDiagramFromText = async (description: string): Promise<string> => {
    const apiKey = process.env.API_KEY;
    if (!apiKey) throw new Error("API Key missing");
    const ai = new GoogleGenAI({ apiKey });

    const prompt = `You are an expert in academic diagrams. Create a high-quality SVG based on: "${description}".
    REQUIREMENTS:
    - Use clean black lines (stroke="#000") and white backgrounds.
    - Use clear font for labels.
    - Must be responsive (use viewBox, width="100%", height="auto").
    - Output ONLY valid SVG code, no explanation.`;

    const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: { temperature: 0.4, responseMimeType: "text/plain" }
    });

    let svg = response.text || "";
    return svg.replace(/```xml|```svg|```/g, "").trim();
};